# -*- coding:UTF-8 -*-
import requests
from bs4 import BeautifulSoup

url = 'https://www.douyu.com/3168536'

r = requests.get(url)
soup = BeautifulSoup(r.text, 'lxml')
# content = soup.find_all('span', {'class':'hot-v'},{'data-anchor-info':'hot'})
content = soup.find_all('span', {'class':'acinfo-fs-con clearfix'})
print(content)