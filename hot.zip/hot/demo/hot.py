# -*- coding: utf-8 -*-
#coding=utf-8
from selenium import webdriver
import sys
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.keys import Keys

import time
reload(sys)
sys.setdefaultencoding("utf-8")
# browser = webdriver.Firefox() # Get local session of firefox
# browser.get("https://v.douyu.com/show/dyVY8WwgLYBWLOz9")
driver = webdriver.PhantomJS()
driver.get("https://www.douyu.com/3605965")
content = driver.page_source
print content
# time.sleep(5)

# print driver.page_source().find("hot-v","hot").text.encode('GBK', 'ignore')
# print driver.find_element_by_class_name("hot-v").text.encode('GBK', 'ignore')
# print driver.find_element_by_class_name("hot-v")
# print driver.find_element_by_xpath("//span[contains(@class,'hot-v')]").text.encode('GBK', 'ignore')